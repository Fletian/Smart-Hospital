package android.graduate.SmartHospital;

import org.apache.http.client.methods.*;

import android.app.Activity;
import android.os.*;

public class Hospitalinfo extends Activity {
	 public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.hospitalinfo);
	 }
}